export class ReceitasDto{
    receita  :        String;
    ingredientes : string;
    modo_preparo :    String;
    link_imagem   :   String;
    tipo          :   String;
    IngredientesBase : {};
}